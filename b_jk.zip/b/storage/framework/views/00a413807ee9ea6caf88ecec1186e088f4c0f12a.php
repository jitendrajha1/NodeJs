<?php $__env->startSection('content'); ?>
<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Table Examples</h2>   
                        <h5>Welcome Jhon Deo , Love to see you back. </h5>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               <strong> <?php if(Session::has('flash_message')): ?>
    <div class="alert alert-success" style="margin-left:404px; width: 325px; float: left; text-align: center;">
        <?php echo e(Session::get('flash_message')); ?>

    </div>
<?php endif; ?></strong
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                            <div class="add-members" style="float: right;">
                                <a href="<?php echo e(route('admin.add-blogs')); ?>">Add Blogs</a>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1;?>
                                        <?php foreach($blogs as $blog): ?>
                                            <tr>
                                                <td><?php echo e($i); ?></td>
                                                <td><?php echo e($blog->title); ?></td>
                                                <td><?php echo e($blog->description); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.edit-blogs',encrypt($blog->id))); ?>" title="Edit/View">
                                                        <i class="fa fa-pencil-square-o"></i>
                                                    </a>
                                                    <a href="#" title="Delete" class="delete-blog" blog-id="<?php echo e($blog->id); ?>">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php $i++; ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
<script type="text/javascript">
    jQuery(document).ready(function(){
        var site_url='http://localhost/b';
        jQuery('.delete-blog').click(function () {
            var id = jQuery(this).attr('blog-id');
            var tocken = jQuery('meta[name=csrf-token]').attr('content');
            var newThis = jQuery(this);
            if (confirm('Are you sure?')){
                jQuery.ajax({
                    type: 'POST',
                    url: site_url + '/admin/delete-blog',
                    data: {
                      'blog_id': id,
                      '_token': tocken
                    },
                    success: function (rsp) {
                        if(rsp == 'TRUE'){
                           newThis.parents('tr').hide();
                        }else{
                            alert('Error!');
                        }
                    }
                });
            }
        });
    });
</script>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>