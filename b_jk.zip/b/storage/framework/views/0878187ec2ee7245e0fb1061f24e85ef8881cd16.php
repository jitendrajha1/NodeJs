<?php $__env->startSection('content'); ?>
<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Forms Page</h2>   
                        <h5>Welcome Jhon Deo , Love to see you back. </h5>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
                 <strong> <?php if(Session::has('flash_message')): ?>
    <div class="alert alert-success" style="margin-left:404px; width: 325px; float: left; text-align: center;">
        <?php echo e(Session::get('flash_message')); ?>

    </div>
<?php endif; ?></strong

               <div class="row">
                <div class="col-md-12">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form Element Examples
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <h3>Basic Form Examples</h3>
                                    <form action="<?php echo e(route('admin.add-blogs')); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <label>Blog Title:</label>
                                            <input type="text" name="title" class="form-control" placeholder="Membr Event Name"/>
                                            <?php if($errors->has('title')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('title')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Short Description</label>
                                            <textarea name="description" class="form-control" rows="3"></textarea>
                                            <?php if($errors->has('description')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label>File input</label>
                                            <input type="file" name="blog_image"/>
                                            <?php if($errors->has('blog_image')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('blog_image')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                        <button type="reset" class="btn btn-primary">Reset Button</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Form Elements -->
                </div>
            </div>
        </div>
             <!-- /. PAGE INNER  -->
    </div>
         <!-- /. PAGE WRAPPER  -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>