		
		
		<script src="<?php echo e(asset('/public/admin/js/bootstrap.min.js')); ?>"></script>
		<script src="<?php echo e(asset('/public/admin/js/jquery.metisMenu.js')); ?>"></script>
		<script src="<?php echo e(asset('/public/admin/js/morris/raphael-2.1.0.min.js')); ?>"></script>
		<script src="<?php echo e(asset('/public/admin/js/morris/morris.js')); ?>"></script>
		<script src="<?php echo e(asset('/public/admin/js/dataTables/jquery.dataTables.js')); ?>"></script>
       <script src="<?php echo e(asset('/public/admin/js/dataTables/dataTables.bootstrap.js')); ?>"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
        </script>
		<script src="<?php echo e(asset('/public/admin/js/custom.js')); ?>"></script>
	</body>
</html>