@include('admin.common.header')
	@include('admin.common.left_sidebar')
		@yield('content')
@include('admin.common.footer')