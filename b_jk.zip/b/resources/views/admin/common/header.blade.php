<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta charset="utf-8" />
        <title>Free Bootstrap Admin Template : Binary Admin</title>

        <link href="{{ asset('/public/admin/css/bootstrap.css') }}" rel="stylesheet" />
        <link href="{{ asset('/public/admin/css/font-awesome.css') }}" rel="stylesheet" />
        <link href="{{ asset('/public/admin/js/morris/morris-0.4.3.min.css') }}" rel="stylesheet" />
        <link href="{{ asset('/public/admin/css/custom.css') }}" rel="stylesheet" />
       <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
       <script src="{{  asset('/public/admin/js/jquery-1.10.2.js') }}"></script>
       <meta name="csrf-token" content="{{ csrf_token() }}">
    </head>
    <body>
       <div id="wrapper">
            <!-- Header -->
            <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">Binary admin</a> 
                </div>
                <div style="color: white; padding: 15px 50px 5px 50px; float: right; font-size: 16px;">     Last access : 30 May 2014 &nbsp; 
                    <a href="{{ url('/logout') }}" class="btn btn-danger square-btn-adjust">Logout</a>
                </div>
            </nav>   
            <!-- End Header -->