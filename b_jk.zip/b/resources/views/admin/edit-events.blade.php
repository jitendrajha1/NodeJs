@extends('layouts.admin_layout')
@section('content')
<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Forms Page</h2>   
                        <h5>Welcome Jhon Deo , Love to see you back. </h5>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
                 <?php 
                   /* echo "<pre>";
                    print_r($event);
                    exit;*/
                 ?>
               <div class="row">
                <div class="col-md-12">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form Element Examples
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <h3>Basic Form Examples</h3>
                                    <form action="{{ route('admin.edit-events',$id) }}" method="POST" enctype="multipart/form-data">
                                        {{ csrf_field() }}
                                        <div class="form-group">
                                            <label>Event Name:</label>
                                            <input type="text" name="event_name" value="{{ $event->title }}" class="form-control"placeholder="Membr Event Name"/>
                                            @if ($errors->has('event_name'))
                                                <span class="help-block">
                                                    <strong>{{ $errors->first('event_name') }}</strong>
                                                </span>
                                            @endif
                                        </div>
                                        <div class="form-group">
                                            <label>Short Description</label>
                                            <textarea name="description" class="form-control" rows="3">{{ $event->description }}</textarea>
                                            @if ($errors->has('description'))
                                                <span class="help-block">
                                                    <strong>{{ $errors->first('description') }}</strong>
                                                </span>
                                            @endif
                                        </div>
                                        <div class="form-group">
                                            <label>File input</label>
                                            <input type="file" name="event_image"/>
                                             @if ($errors->has('event_image'))
                                                <span class="help-block">
                                                    <strong>{{ $errors->first('event_image') }}</strong>
                                                </span>
                                            @endif
                                            <div class="event-class"><img src="{{ asset('/public/events/'.$event->img) }}" ></div>
                                        </div>
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                        <button type="reset" class="btn btn-primary">Reset Button</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Form Elements -->
                </div>
            </div>
        </div>
    <!-- /. PAGE INNER  -->
    </div>
    <!-- /. PAGE WRAPPER  -->
</div>
@endsection