<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use App\User;
use App\Event;
use App\Gallery;
use App\UserProfile;
use App\Blog;
use App\News;
use Session;    
use Redirect;

class AdminController extends Controller
{
    /*
        @admin log In
        @Author: Jitendra
    */
    public function login(Request $request){
        if($request->isMethod('POST')){
            $this->validate($request,[
                'email' => 'required',
                'password' => 'required'
            ]);
            $email = $request->get('email');
            $password = $request->get('password');
            if (Auth::attempt(['email' => $email, 'password' => $password, 'status' => 1])){
                $userRole = trim(Auth::user()->roles[0]->title);
                if($userRole == 'admins'){
                    return redirect()->intended('/admin/dashboard');
                }
                else{
                    Session::flash('flash_message', 'Opp! Please contact to super admin');
                    return Redirect()->back();
                }
            }else{
                Session::flash('flash_message', 'Either email/password is wrong');
                return Redirect()->back();
            }
        }else{
            return view('admin.login');
        }
    }
    /*
        @admin Dashboard
        @Autjor: Jitendra
    */
    public function index(){
    	return view('admin.dashboard');
    }
    /*
        @Members Listings
        @Author: Jitendra
    */
    public function memberLists(){
        //User::with('profile')->where('id',3)->get();
        $members = User::with('profile')->where('status',1)->where('super_admin',0)->get();
    	return view('admin.members',['members' => $members]);
    }
    /*
        @Add Members
        @Author: Jitendra
    */
    public function addMembers(Request $request){
        if($request->isMethod('POST')){
            $this->validate($request,[
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email|unique:users',
                'password' => 'required',
                'phone' => 'required',
                'branch' => 'required',
                'address' => 'required',
                'description' => 'required',
                'profile_image' => 'required|image|mimes:jpeg,jpg,png',
                'area_of_interest' => 'required',
                'sex' => 'required',
                'year' => 'required'
            ]);
            $user = new User;
            $interest = implode(',', $request->get('area_of_interest'));
            $user->name = $request->get('first_name').' '.$request->get('last_name');
            $user->email = $request->get('email');
            $user->password = bcrypt($request->get('password'));
            $user->status = 1;
            $roleId = 1;
            $user_profile = new UserProfile;
            $user_profile->mobile = $request->get('phone');
            $user_profile->branch = $request->get('branch');
            $user_profile->address = $request->get('address');
            $user_profile->description = $request->get('description');
            $user_profile->interest = $interest;
            $user_profile->gender = $request->get('sex');
            $user_profile->year = $request->get('year');
            $image = $request->file('profile_image'); 
            $fileExtension = $image->getClientOriginalExtension();
            $imageName =time().'.'.$fileExtension; 
            $request->file('profile_image')->move(base_path() . '/public/membres/', $imageName);
            $user_profile->img = $imageName;
            if($user->save()){
                $user->roles()->attach($roleId);
                $user->profile()->save($user_profile);
                Session::flash('flash_message', 'Member Added Successfully!');
                return Redirect('/admin/members');
            }else{
                Session::flash('flash_message', 'Please Contact To Super Admin');
                return redirect()->back();
            }
        }else{
    	   return view('admin.add-members');
        }
    }
    /*
        @Edit Member Listings
        @Author: Jitendra
    */
    public function editMembers(Request $request,$userId){
        $id = decrypt($userId);
        if($request->isMethod('POST')){
            $user = User::findOrFail($id);
            $this->validate($request,[
                'first_name' => 'required',
                'last_name' => 'required',
                'phone' => 'required',
                'branch' => 'required',
                'address' => 'required',
                'description' => 'required',
                'sex' => 'required',
                'year' => 'required'
            ]);
            $user->name = $request->get('first_name').' '.$request->get('last_name');
            $user = User::with('profile')->where('id',$id)->first();
            $user_profile = UserProfile::findOrFail($user['profile']->id);
            $user_profile->mobile = $request->get('phone');
            $user_profile->branch = $request->get('branch');
            $user_profile->address = $request->get('address');
            $user_profile->description = $request->get('description');
            $user_profile->gender = $request->get('sex');
            $user_profile->year = $request->get('year');
            $user_profile->img = 'anc.png';
            if($user->save()){
                $user = 
                $user->profile()->save($user_profile);
                Session::flash('flash_message', 'Member Updated Successfully!');
                return Redirect('/admin/members');
            }else{
                Session::flash('flash_message', 'Please Contact To Super Admin');
                return redirect()->back();
            }
        }else{
            $user = User::with('profile')->where('id',$id)->first();
            return view('admin.edit-members',['user' => $user,'id' => $userId]);
        }
    }
    /*
        @Delete Users
        @Author: Jitendra
    */
    public function deleteMember(Request $request){
        $id = $request->get('member_id');
        $user = User::findOrFail($id);
        if($user->delete()){
            echo "TRUE";
        }else{
            echo "FALSE";
        }
    }
    /*
        @Event Listings
        @Author: Jitendra
    */
    public function eventLists(){
        $events = Event::get();
    	return view('admin.events',['events' => $events]);
    }
    /*
        @Add Events
        @Author: Jitendra
    */
    public function addEvents(Request $request){
        if($request->isMethod('POST')){
            $this->validate($request,[
                'event_name' => 'required',
                'description' => 'required|',
                'event_image' => 'required|image|mimes:jpeg,jpg,png'
            ]);
            $event = new Event;
            $event->title = $request->get('event_name');
            $event->description = $request->get('description');
            if($request->hasFile('event_image')){ 
                $image = $request->file('event_image'); 
                $fileExtension = $image->getClientOriginalExtension();
                $imageName =time().'.'.$fileExtension; 
                $request->file('event_image')->move(base_path() . '/public/events/', $imageName);
                $event->img = $imageName;
                if($event->save()){
                    Session::flash('flash_message', 'Event Added successfully!');
                    return Redirect('/admin/events');
                }else{
                    Session::flash('flash_message', 'Oops! Please try again');
                    return redirect()->back();
                }
            }else{
                Session::flash('flash_message', 'Please Contact To Super Admin');
                return redirect()->back();
            }
        }else{
    	   return view('admin.add-events');
        }
    }
    /*
        @Edit Events
        @Author: Jitendra
    */
    public function editEvents(Request $request, $eventId){
        $id = decrypt($eventId);
        if($request->isMethod('POST')){
            $event = Event::findOrFail($id);
            if($request->hasFile('event_image')){
                $this->validate($request,[
                    'event_name' => 'required',
                    'description' => 'required|',
                    'event_image' => 'required|image|mimes:jpeg,jpg,png'
                ]);
                $event->title = $request->get('event_name');
                $event->description = $request->get('description');
                $image = $request->file('event_image'); 
                $fileExtension = $image->getClientOriginalExtension();
                $imageName =time().'.'.$fileExtension; 
                $request->file('event_image')->move(base_path() . '/public/events/', $imageName);
                $event->img = $imageName;
                if($event->save()){
                    Session::flash('flash_message', 'Event Updated successfully!');
                    return Redirect('/admin/events');
                }else{
                    Session::flash('flash_message', 'Oops! Please try again');
                    return redirect()->back();
                }
            }else{
                $this->validate($request,[
                    'event_name' => 'required',
                    'description' => 'required|'
                ]);
                $event->title = $request->get('event_name');
                $event->description = $request->get('description');
                if($event->save()){
                    Session::flash('flash_message', 'Event Updated successfully!');
                    return Redirect('/admin/events');
                }else{
                    Session::flash('flash_message', 'Oops! Please try again');
                    return redirect()->back();
                }
            }
        }else{
            $event = Event::where('id',$id)->first();
            return view('admin.edit-events',['event' => $event, 'id' =>$eventId ]);
        }
    }
    /*
        @Delete Event
        @Author: Jitendra
    */
    public function deleteEvent(Request $request){
        $id = $request->get('event_id');
        $user = Event::findOrFail($id);
        if($user->delete()){
            echo "TRUE";
        }else{
            echo "FALSE";
        }
    }
    /*
        @Gallery Listings
        @Author: Jitendra
    */
    public function galleryLists(){
        $galleries = Gallery::get();
    	return view('admin.gallery',['galleries' => $galleries]);
    }
    /*
        @Add Images
        @Author: Jitendra
    */
    public function addImages(Request $request){
        if($request->isMethod('POST')){
            $this->validate($request,[
                'title' => 'required',
                'gallery_image' => 'required|image|mimes:jpeg,jpg,png'
            ]);
            $gallery = new Gallery;
            $gallery->title = $request->get('title');
            if($request->hasFile('gallery_image'))
            {
                $image = $request->file('gallery_image'); 
                $fileExtension = $image->getClientOriginalExtension();
                $imageName =time().'.'.$fileExtension; 
                $request->file('gallery_image')->move(base_path() . '/public/gallery/', $imageName);
                $gallery->img = $imageName;
                if($gallery->save()){
                    Session::flash('flash_message', 'Gallery Image Added successfully!');
                    return Redirect('/admin/gallery');
                }else{
                    Session::flash('flash_message', 'Oops! Please try again');
                    return redirect()->back();
                }
            }
        }else{
    	   return view('admin.add-images');
        }
    }
    /*
        @Delete Gallery
        @Author: Jitendra
    */
    public function deleteGallery(Request $request){
        $id = $request->get('gallery_id');
        $user = Gallery::findOrFail($id);
        if($user->delete()){
            echo "TRUE";
        }else{
            echo "FALSE";
        }
    }
    /*
        @Blog Listings
        @Author: Jitendra
    */
    public function blogLists(){
        $blogs = Blog::get();
    	return view('admin.blogs',['blogs' => $blogs]);
    }
    /*
        @Add Blogs
        @Author: Jitendra
    */
    public function addBlogs(Request $request){
        if($request->isMethod('POST')){
            $this->validate($request,[
                'title' => 'required',
                'description' => 'required',
                'blog_image' => 'required|image|mimes:jpeg,jpg,png'
            ]);
            $blog = new Blog;
            $blog->title = $request->get('title');
            $blog->description = $request->get('description');
            if($request->hasFile('blog_image')){
                $image = $request->file('blog_image'); 
                $fileExtension = $image->getClientOriginalExtension();
                $imageName =time().'.'.$fileExtension; 
                $request->file('blog_image')->move(base_path() . '/public/blogs/', $imageName);
                $blog->img = $imageName;
                if($blog->save()){
                    Session::flash('flash_message', 'Blog Added successfully!');
                    return Redirect('/admin/blogs');
                }else{
                    Session::flash('flash_message', 'Oops! Please try again');
                    return redirect()->back();
                }
            }else{
                Session::flash('flash_message', 'Please! Contact To Super Admin');
                return redirect()->back();
            }
        }else{
    	   return view('admin.add-blogs');
        }
    }
    /*
        @Edit Blog
        @Author: Jitendra
    */
    public function editBlogs(Request $request, $blogId){
        $id = decrypt($blogId);
        if($request->isMethod('POST')){
            $blog = Blog::findOrFail($id);
            if($request->hasFile('blog_image')){
                $this->validate($request,[
                    'title' => 'required',
                    'description' => 'required|',
                    'blog_image' => 'required|image|mimes:jpeg,jpg,png'
                ]);
                $blog->title = $request->get('title');
                $blog->description = $request->get('description');
                $image = $request->file('blog_image'); 
                $fileExtension = $image->getClientOriginalExtension();
                $imageName =time().'.'.$fileExtension; 
                $request->file('blog_image')->move(base_path() . '/public/blogs/', $imageName);
                $blog->img = $imageName;
                if($blog->save()){
                    Session::flash('flash_message', 'Blog Updated successfully!');
                    return Redirect('/admin/blogs');
                }else{
                    Session::flash('flash_message', 'Oops! Please try again');
                    return redirect()->back();
                }
            }else{
                $this->validate($request,[
                    'title' => 'required',
                    'description' => 'required|'
                ]);
                $blog->title = $request->get('title');
                $blog->description = $request->get('description');
                if($blog->save()){
                    Session::flash('flash_message', 'Blog Updated successfully!');
                    return Redirect('/admin/blogs');
                }else{
                    Session::flash('flash_message', 'Oops! Please try again');
                    return redirect()->back();
                }
            }
        }else{
            $blog = Blog::where('id',$id)->first();
            return view('admin.edit-blogs',['blog' => $blog, 'id' => $blogId]);
        }
    }
    /*
        @Delete Blog
        @Author: Jitendra
    */
    public function deleteBlog(Request $request){
        $id = $request->get('blog_id');
        $blog = Blog::findOrFail($id);
        if($blog->delete()){
            echo "TRUE";
        }else{
            echo "FALSE";
        }
    }
    /*
        @News Listings
        @Author: Jitendra
    */
    public function newsLists(){
        $news = News::get();
    	return view('admin.news',['news' => $news]);
    }
    /*
        @Add News
        @Author: Jitendra
    */
    public function addNews(Request $request){
        if($request->isMethod('POST')){
            $this->validate($request,[
                'title' => 'required',
                'description' => 'required'
            ]);
            $news = new News;
            $news->title = $request->get('title');
            $news->description = $request->get('description');
            if($news->save()){
                Session::flash('flash_message', 'News Added successfully!');
                return Redirect('/admin/news');
            }else{
                Session::flash('flash_message', 'Oops! Please try again');
                return redirect()->back();
            }
        }else{
    	   return view('admin.add-news');
        }
    }
    /*
        @Edit News
        @Author: Jitendra
    */
    public function editNews(Request $request, $newsId){
        $id = decrypt($newsId);
        if($request->isMethod('POST')){
            $news = News::findOrFail($id);
            $this->validate($request,[
                'title' => 'required',
                'description' => 'required'
            ]);
            $news->title = $request->get('title');
            $news->description = $request->get('description');
            if($news->save()){
                Session::flash('flash_message', 'News Updated successfully!');
                return Redirect('/admin/news');
            }else{
                Session::flash('flash_message', 'Oops! Please try again');
                return redirect()->back();
            }
        }else{
            $news = News::where('id',$id)->first();
            return view('admin.edit-news',['news' => $news, 'id' => $newsId]);
        }
    }
    /*
        @Delete Blog
        @Author: Jitendra
    */
    public function deleteNews(Request $request){
        $id = $request->get('news_id');
        $news = News::findOrFail($id);
        if($news->delete()){
            echo "TRUE";
        }else{
            echo "FALSE";
        }
    }
    /*
        @Cms Pages Management
        @Author: Jitendra
    */
    public function cms(){
    	return view('admin.blank');
    }

}
