vti_encoding:SR|utf8-nl
vti_author:SR|paullouienaz-PC\\paullouienaz
vti_modifiedby:SR|paullouienaz-PC\\paullouienaz
vti_timelastmodified:TR|17 May 2016 10:49:20 -0000
vti_timecreated:TR|15 May 2016 10:20:21 -0000
vti_title:SR|CLASS21ST
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|login.php
vti_nexttolasttimemodified:TW|17 May 2016 10:48:59 -0000
vti_syncwith_localhost\\c\:\\inetpub\\wwwroot\\class21st\\class21st-1.1.0\\html2/c\:/inetpub/wwwroot/class21st/class21st-1.1.0/html2:TR|15 May 2016 12:33:10 -0000
vti_cacheddtm:TX|17 May 2016 10:49:20 -0000
vti_filesize:IR|10043
vti_cachedtitle:SR|CLASS21ST
vti_cachedbodystyle:SR|<body class="login">
vti_cachedlinkinfo:VX|Q|css/vendor/all.css Q|css/app/app.css X|https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js X|https://oss.maxcdn.com/respond/1.4.2/respond.min.js Q|css/bg_img_fader.css S|/images/1.jpg S|/images/2.jpg S|images/people/110/default.jpg H|website-student-dashboard.html K|login.php H|sign-up.html S|js/vendor/all.js S|js/app/app.js
vti_cachedsvcrellinks:VX|FQUS|css/vendor/all.css FQUS|css/app/app.css NXSS|https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js NXSS|https://oss.maxcdn.com/respond/1.4.2/respond.min.js FQUS|css/bg_img_fader.css NSUS|/images/1.jpg NSUS|/images/2.jpg FSUS|images/people/110/default.jpg FHUS|website-student-dashboard.html FKUS|login.php FHUS|sign-up.html FSUS|js/vendor/all.js FSUS|js/app/app.js
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=X-UA-Compatible IE=edge viewport width=device-width,\\ initial-scale=1 description author
vti_charset:SR|utf-8
