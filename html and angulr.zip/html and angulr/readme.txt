### What's included

<downloaded-package>
├── <html>          // Includes the static HTML version
├── <angular>       // Includes the static AngularJS version
├── <docs>          // Documentation
├── <lib>           // Various libraries used within the source
└── <src>           // Source

### Usage

See docs/index.html