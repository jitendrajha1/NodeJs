@include('instructor.common.header')
@include('instructor.common.left_sidebar')
 	@yield('content')
@include('instructor.common.footer')