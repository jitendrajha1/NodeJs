<!-- Sidebar component with st-effect-1 (set on the toggle button within the navbar) -->
<div class="sidebar left sidebar-size-3 sidebar-offset-0 sidebar-visible-desktop sidebar-visible-mobile sidebar-skin-dark" id="sidebar-menu" data-type="collapse">
  <div data-scrollable>
    <div class="sidebar-block">
      <div class="profile">
        <a href="#">
          <img src="{{ asset('/public/images/people/110/guy-6.jpg') }}" alt="people" class="img-circle width-80" />
        </a>
        <h4 class="text-display-1 margin-none">Jitendra Jha</h4>
      </div>
    </div>
    <!-- Instructor -->
    <ul class="sidebar-menu">
      <li class="active">
        <a href="{{ route('instructor.dashboard')}}">
          <i class="fa fa-home"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li>
        <a href="{{ route('instructor.messages') }}">
          <i class="fa fa-paper-plane"></i>
          <span>Messages</span>
        </a>
      </li>
      <li>
        <a href="{{ route('instructor.courses') }}">
          <i class="fa fa-mortar-board"></i>
          <span>My Courses</span>
        </a>
      </li>
      <li>
        <a href="{{ route('instructor.earnings') }}">
          <i class="fa fa-bar-chart-o"></i>
          <span>Earnings</span>
        </a>
      </li>
      <li>
        <a href="{{ route('instructor.statement') }}">
          <i class="fa fa-dollar"></i>
          <span>Statement</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="fa fa-sign-out"></i>
          <span>Logout</span>
        </a>
      </li>
    </ul>
  </div>
</div>
<!-- sidebar effects OUTSIDE of st-pusher: -->
<!-- st-effect-1, st-effect-2, st-effect-4, st-effect-5, st-effect-9, st-effect-10, st-effect-11, st-effect-12, st-effect-13 -->