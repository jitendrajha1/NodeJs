<?php

namespace App\Http\Controllers\Instructor;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class InstructorController extends Controller
{	/*
		@Instructor dashboard
		@Author: Jitendra
	*/
    public function index(){
    	return view('instructor.dashboard');
    }
    /*
		@Instructor Earnings
		@Author: Jitendra
	*/
	public function earnings(){
		return view('instructor.earnings');
	}
	/*
		@Instructor statement
		@Author: Jitendra
	*/
	public function statement(){
		return view('instructor.statement');
	}
	/*
		@Instructor Message
		@Author: Jitendra
	*/
	public function message(){
		return view('instructor.messages');
	}
	public function profile(){
		return view('instructor.profile');
	}
	public function billing(){
		return view('instructor.billing');
	}
}
