<?php

namespace App\Http\Controllers\Instructor;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class CourseController extends Controller
{
 	/*
		@Instructor Courses
		@Author: Jitendra
	*/
    public function index(){
    	return view('instructor.courses');
    }
    /*
		@Instructor Edit Courses
		@Author: Jitendra
	*/
	public function editCourses(){
		return view('instructor.edit_course');
	}
	/*
		@Instructor Course meta
		@Author: Jitendra
	*/
	public function courseMeta(){
		return view('instructor.course_edit_meta');
	}
	/*
		@Instructor Course Lesson
		@Author: Jitendra
	*/
	public function courseLesson(){
		return view('instructor.course_edit_lessons');
	}
}
