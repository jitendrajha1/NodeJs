<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;

use App\User;
use Session;
use Redirect;
use Auth;

class HomeController extends Controller
{
    /*
        @Front End Dashboard
        @form data
        @Author: Jitendra
    */
    public function index()
    {
        return view('home_page');
    }
    /*
        @Students and Instructor LogIn
        @Email Id and Password
        @Author: Jitendra
    */
    public function login(Request $request){
        if($request->isMethod('POST')){
            $this->validate($request,[
                'email' => 'required',
                'password' => 'required'
            ]);
            $email = $request->get('email');
            $password = $request->get('password');
            if (Auth::attempt(['email' => $email, 'password' => $password, 'status' => 1])){
                $userRole = trim(Auth::user()->roles[0]->title);
                if($userRole == 'instructor'){
                    return redirect()->intended('/instructor/dashboard');
                }
                else if($userRole == 'student'){
                    return redirect()->intended('/student/dashboard');
                }
                else{
                    Session::flash('flash_message', 'Opp! Please contact to admin');
                    return Redirect()->back();
                }
            }else{
                Session::flash('flash_message', 'Either email/password is wrong');
                return Redirect()->back();
            }
        }else{
            return view('login');
        }
    }
    /*
        @Students and Instructor Registration
        @form data
        @Author: Jitendra
    */
    public function registration(Request $request){
        if($request->isMethod('POST')){
            $this->validate($request, [
                'firstName' => 'required',
                'lastName' => 'required',
                'email' => 'required|email|unique:users',
                'password' => 'required',
                'terms&conditions' => 'required',
                'type' => 'required'
            ]);
            $user =  new User;
            $user->name = $request->get('firstName').' '.$request->get('lastName');
            $user->email = $request->get('email');
            $user->password  = bcrypt($request->get('password'));
            $user->status = 1;
            if($request->get('type') == 'student'){
                $id = 1;
            }else{
                $id = 2;
            }
            if($user->save())
            {
                $user->roles()->attach($id);
                Session::flash('flash_message', 'Thank you for registering with us!. Please login to continue');
                return Redirect('/');
            }else{
                Session::flash('flash_message', 'Opps! Please Try again OR contact to admin');
                return Redirect()->back();
            }
        }else{
            return view('registration');
        }
    }
}
