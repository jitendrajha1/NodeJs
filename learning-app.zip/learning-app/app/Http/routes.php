<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
Route::get('/', 'HomeController@index');
Route::get('/login', 'HomeController@login');
Route::post('/login', 'HomeController@login');
Route::get('/sign-up', 'HomeController@registration');
Route::post('/sign-up', 'HomeController@registration');

$this->get('logout', 'Auth\AuthController@logout');

/*******************Instructor Routes*********************************************/
Route::group(['namespace' => 'Instructor', 'prefix'=> 'instructor','as' => 'instructor.','middleware' => 'auth'], function() {
    Route::get('/dashboard', [ 'as' =>'dashboard', 'uses' => 'InstructorController@index' ] );
    Route::get('/courses',['as' => 'courses', 'uses' => 'CourseController@index'] );
    Route::get('/edit-course',['as' => 'edit-course', 'uses' => 'CourseController@editCourses'] );
    Route::get('/course-edit-meta',['as' => 'course-edit-meta', 'uses' => 'CourseController@courseMeta'] );
    Route::get('/course-edit-lessons',['as' => 'course-edit-lessons', 'uses' => 'CourseController@courseLesson'] );
    Route::get('/earnings', [ 'as' =>'earnings', 'uses' => 'InstructorController@earnings' ] );
    Route::get('/statement', [ 'as' =>'statement', 'uses' => 'InstructorController@statement' ] );
    Route::get('/messages', [ 'as' =>'messages', 'uses' => 'InstructorController@message' ] );
    Route::get('/profile', [ 'as' =>'profile', 'uses' => 'InstructorController@profile' ] );
    Route::get('/billing', [ 'as' =>'billing', 'uses' => 'InstructorController@billing' ] );
});

/*******************Students Routes*********************************************/

Route::group(['namespace' => 'Student', 'prefix' => 'student', 'as' => 'student.'], function () {
    Route::get('/dashboard', ["as" => 'dashboard', 'uses' => 'StudentController@index']);
    Route::get('/courses/{courses?}', ["as" => 'courses', 'uses' => 'CourseController@index']);
    Route::get('/take-course', ["as" => 'course', 'uses' => 'CourseController@takeCourse']);
    Route::get('/forums', ["as" => 'forums', 'uses' => 'CourseController@forums']);
    Route::get('/forums-thread', ["as" => 'forum-thread', 'uses' => 'CourseController@forumsThread']);
    Route::get('/quiz', ["as" => 'quiz', 'uses' => 'QuizController@index']);
    Route::get('/messages', ["as" => 'messages', 'uses' => 'StudentController@messages']);
    Route::get('/profile', ["as" => 'profile', 'uses' => 'StudentController@profile']);
    Route::get('/billing', ["as" => 'billing', 'uses' => 'StudentController@billing']);
});


/*Route::auth();

// Authentication Routes...
$this->get('login', 'Auth\AuthController@showLoginForm');
$this->post('login', 'Auth\AuthController@login');
$this->get('logout', 'Auth\AuthController@logout');

// Registration Routes...
$this->get('register', 'Auth\AuthController@showRegistrationForm');
$this->post('register', 'Auth\AuthController@register');

// Password Reset Routes...
$this->get('password/reset/{token?}', 'Auth\PasswordController@showResetForm');
$this->post('password/email', 'Auth\PasswordController@sendResetLinkEmail');
$this->post('password/reset', 'Auth\PasswordController@reset');



Route::get('/home', 'HomeController@index');*/
