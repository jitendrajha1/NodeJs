<?php $__env->startSection('content'); ?>
  <!-- content push wrapper -->
  <div class="st-pusher" id="content">
    <!-- sidebar effects INSIDE of st-pusher: -->
    <!-- st-effect-3, st-effect-6, st-effect-7, st-effect-8, st-effect-14 -->
    <!-- this is the wrapper for the content -->
    <div class="st-content">
      <!-- extra div for emulating position:fixed of the menu -->
      <div class="st-content-inner padding-none">
        <div class="container-fluid">
          <div class="page-section">
            <h1 class="text-display-1">Create New Course</h1>
          </div>
          <!-- Tabbable Widget -->
          <div class="tabbable paper-shadow relative" data-z="0.5">
            <!-- Tabs -->
            <ul class="nav nav-tabs">
              <li>
                <a href="<?php echo e(route('instructor.edit-course')); ?>">
                  <i class="fa fa-fw fa-lock"></i>
                  <span class="hidden-sm hidden-xs">Course</span>
                </a>
              </li>
              <li>
                <a href="<?php echo e(route('instructor.course-edit-meta')); ?>">
                  <i class="fa fa-fw fa-credit-card"></i>
                  <span class="hidden-sm hidden-xs">Meta</span>
                </a>
              </li>
              <li class="active">
                <a href="<?php echo e(route('instructor.course-edit-lessons')); ?>">
                  <i class="fa fa-fw fa-credit-card"></i>
                  <span class="hidden-sm hidden-xs">Lessons</span>
                </a>
              </li>
            </ul>
            <!-- // END Tabs -->
            <!-- Panes -->
            <div class="tab-content">
              <div id="lessons" class="tab-pane active">
                <div class="media v-middle s-container">
                  <div class="media-body">
                    <h5 class="text-subhead text-light">3 Lessons</h5>
                  </div>
                  <div class="media-right">
                    <a class="btn btn-primary paper-shadow relative" href="">Add lesson</a>
                  </div>
                </div>
                <div class="nestable" id="nestable-handles-primary">
                  <ul class="nestable-list">
                    <li class="nestable-item nestable-item-handle" data-id="1">
                      <div class="nestable-handle"><i class="md md-menu"></i></div>
                      <div class="nestable-content">
                        <div class="media v-middle">
                          <div class="media-left">
                            <div class="icon-block half bg-red-400 text-white">
                              <i class="fa fa-github"></i>
                            </div>
                          </div>
                          <div class="media-body">
                            <h4 class="text-title media-heading margin-none">
                              <a href="" class="link-text-color">Github Webhooks for Beginners</a>
                            </h4>
                            <div class="text-caption">updated 1 month ago</div>
                          </div>
                          <div class="media-right">
                            <a href="" class="btn btn-white btn-flat"><i class="fa fa-pencil fa-fw"></i> Edit</a>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li class="nestable-item nestable-item-handle" data-id="2">
                      <div class="nestable-handle"><i class="md md-menu"></i></div>
                      <div class="nestable-content">
                        <div class="media v-middle">
                          <div class="media-left">
                            <div class="icon-block half bg-blue-400 text-white">
                              <i class="fa fa-css3"></i>
                            </div>
                          </div>
                          <div class="media-body">
                            <h4 class="text-title media-heading margin-none">
                              <a href="" class="link-text-color">Awesome CSS with LESS Processing</a>
                            </h4>
                            <div class="text-caption">updated 1 month ago</div>
                          </div>
                          <div class="media-right">
                            <a href="" class="btn btn-white btn-flat"><i class="fa fa-pencil fa-fw"></i> Edit</a>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li class="nestable-item nestable-item-handle" data-id="2">
                      <div class="nestable-handle"><i class="md md-menu"></i></div>
                      <div class="nestable-content">
                        <div class="media v-middle">
                          <div class="media-left">
                            <div class="icon-block half bg-purple-400 text-white">
                              <i class="fa fa-jsfiddle"></i>
                            </div>
                          </div>
                          <div class="media-body">
                            <h4 class="text-title media-heading margin-none">
                              <a href="" class="link-text-color">Browserify: Writing Modular JavaScript</a>
                            </h4>
                            <div class="text-caption">updated 1 month ago</div>
                          </div>
                          <div class="media-right">
                            <a href="" class="btn btn-white btn-flat"><i class="fa fa-pencil fa-fw"></i> Edit</a>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- // END Panes -->
          </div>
          <!-- // END Tabbable Widget -->
        </div>
      </div>
      <!-- /st-content-inner -->
    </div>
    <!-- /st-content -->
  </div>
  <!-- /st-pusher -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.instructor_master_layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>