<?php $__env->startSection('content'); ?>
  <!-- content push wrapper -->
  <div class="st-pusher" id="content">
    <!-- sidebar effects INSIDE of st-pusher: -->
    <!-- st-effect-3, st-effect-6, st-effect-7, st-effect-8, st-effect-14 -->
    <!-- this is the wrapper for the content -->
    <div class="st-content">
      <!-- extra div for emulating position:fixed of the menu -->
      <div class="st-content-inner padding-none">
        <div class="container-fluid">
          <div class="page-section">
            <h1 class="text-display-1">Create New Course</h1>
          </div>
          <!-- Tabbable Widget -->
          <div class="tabbable paper-shadow relative" data-z="0.5">
            <!-- Tabs -->
            <ul class="nav nav-tabs">
              <li class="active">
                <a href="<?php echo e(route('instructor.edit-course')); ?>">
                  <i class="fa fa-fw fa-lock"></i>
                  <span class="hidden-sm hidden-xs">Course</span>
                </a>
              </li>
              <li>
                <a href="<?php echo e(route('instructor.course-edit-meta')); ?>">
                  <i class="fa fa-fw fa-credit-card"></i>
                  <span class="hidden-sm hidden-xs">Meta</span>
                </a>
              </li>
              <li>
                <a href="<?php echo e(route('instructor.course-edit-lessons')); ?>">
                  <i class="fa fa-fw fa-credit-card"></i>
                  <span class="hidden-sm hidden-xs">Lessons</span>
                </a>
              </li>
            </ul>
            <!-- // END Tabs -->
            <!-- Panes -->
            <div class="tab-content">
              <div id="course" class="tab-pane active">
                <form action="">
                  <div class="form-group form-control-material">
                    <input type="text" name="title" id="title" placeholder="Course Title" class="form-control used" value="Basics of HTML" />
                    <label for="title">Title</label>
                  </div>
                  <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description" cols="30" rows="10" class="summernote">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae consectetur dignissimos itaque nesciunt nostrum, provident saepe similique. Delectus dicta distinctio quibusdam velit veniam? Aperiam cum dignissimos doloremque officiis
                      quisquam velit!</textarea>
                  </div>
                </form>
                <div class="text-right">
                  <a href="#" class="btn btn-primary">Save</a>
                </div>
              </div>
            </div>
            <!-- // END Panes -->
          </div>
          <!-- // END Tabbable Widget -->
        </div>
      </div>
      <!-- /st-content-inner -->
    </div>
    <!-- /st-content -->
  </div>
  <!-- /st-pusher -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.instructor_master_layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>