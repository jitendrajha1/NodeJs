<?php

namespace App\Http\Controllers\Super_admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class AdminController.php extends Controller
{
    //
}
