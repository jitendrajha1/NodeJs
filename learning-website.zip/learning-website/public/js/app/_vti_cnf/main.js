vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 May 2015 15:03:50 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|paullouienaz-PC\\paullouienaz
vti_modifiedby:SR|paullouienaz-PC\\paullouienaz
vti_timecreated:TR|30 May 2015 15:03:50 -0000
vti_cacheddtm:TX|30 May 2015 15:03:50 -0000
vti_filesize:IR|10877
vti_backlinkinfo:VX|
vti_syncwith_localhost\\c\:\\inetpub\\wwwroot\\class21st\\class21st-1.1.0\\html2/c\:/inetpub/wwwroot/class21st/class21st-1.1.0/html2:TR|30 May 2015 15:03:50 -0000
