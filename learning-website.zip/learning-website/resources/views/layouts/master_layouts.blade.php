@include('common.top_header')
	@section('header')
		@include('common.header')
	@endsection
 		@yield('content')
@include('common.footer')